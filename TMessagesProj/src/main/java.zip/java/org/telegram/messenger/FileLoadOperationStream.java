package org.telegram.messenger;

public interface FileLoadOperationStream {
    void newDataAvailable();
}
