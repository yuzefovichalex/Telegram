package org.telegram.tgnet;

public interface QuickAckDelegate {
    void run();
}
